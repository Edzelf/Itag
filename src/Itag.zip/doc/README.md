# Itag
Test Itag (Wireless Smart Bluetooth 4.0 Anti lost alarm bluetooth Tracker key finder)
Just enter a list with mac address of the Itags you own to the list in the source code (Itag[]).
The program will scan for the devices, connect to it and react on pressing the Itag button.
The program is just a demo.  The only output are debug lines on the serial port (115200 Bd).

![alt text](https://github.com/Edzelf/Itag/blob/main/itag.jpg?raw=true)
